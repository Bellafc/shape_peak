# 答案位置逐層激活（噪聲基線與去噪形變用）

建立日期：2026-10-07。共 39 個檔案，對應 `events_pack` 裡 `results/events/noise/`、`results/events/cv/` 的 39 組。解壓後把 `results/dims/` 放到 `/workspace/results/dims/` 即可重跑 `overnight/shape_noise.py`、`overnight/shape_cv.py`、`overnight/dir_cos.py`（跨層遷移的離線方向餘弦）。

## 格式

每個檔案是 `torch.save` 的 dict，由 `overnight/dims.py` 產生（與 `group.py` 相同的題目、chat 模板與系統指令）：

| 鍵 | 形狀 / 型別 | 內容 |
|---|---|---|
| `H` | N × L × D，float16 | 答案位置（assistant 開頭前的最後一個 token）每個 decoder 層的輸出殘差；L = 層數（第 L 個 decoder 層的輸出，不含嵌入） |
| `ans` | N | 正確答案的類別編號（分組用） |
| `src` | N | 線索（起點 / 國家 / 首都等）編號 |
| `k` | N | 往後數的步數（計算類任務；其他任務無意義） |
| `wrap` | N | 是否繞回（計算類） |
| `t` | N | 模板（問法）編號 0–2 |

讀取：`a = torch.load(path, weights_only=False); H = a["H"].float()`

## 檔案清單

| 檔案 | 題數 N | 層數 L | 維度 D | 類別數 |
|---|---|---|---|---|
| `Gemma-2-9B-it_capital2hop_acts.pt` | 144 | 42 | 3584 | 6 |
| `Gemma-2-9B-it_city_acts.pt` | 216 | 42 | 3584 | 12 |
| `Gemma-2-9B-it_color_acts.pt` | 144 | 42 | 3584 | 8 |
| `Gemma-2-9B-it_continent_acts.pt` | 144 | 42 | 3584 | 6 |
| `Gemma-2-9B-it_ctxcolor_acts.pt` | 192 | 42 | 3584 | 8 |
| `Gemma-2-9B-it_emotion_acts.pt` | 144 | 42 | 3584 | 8 |
| `Gemma-2-9B-it_hour_acts.pt` | 216 | 42 | 3584 | 12 |
| `Gemma-2-9B-it_letter_acts.pt` | 468 | 42 | 3584 | 26 |
| `Gemma-2-9B-it_month_acts.pt` | 216 | 42 | 3584 | 12 |
| `Gemma-2-9B-it_weekday_acts.pt` | 126 | 42 | 3584 | 7 |
| `Llama-3.1-8B-Instruct_capital2hop_acts.pt` | 144 | 32 | 4096 | 6 |
| `Llama-3.1-8B-Instruct_city_acts.pt` | 216 | 32 | 4096 | 12 |
| `Llama-3.1-8B-Instruct_color_acts.pt` | 144 | 32 | 4096 | 8 |
| `Llama-3.1-8B-Instruct_continent_acts.pt` | 144 | 32 | 4096 | 6 |
| `Llama-3.1-8B-Instruct_ctxcolor_acts.pt` | 192 | 32 | 4096 | 8 |
| `Llama-3.1-8B-Instruct_emotion_acts.pt` | 144 | 32 | 4096 | 8 |
| `Llama-3.1-8B-Instruct_hour_acts.pt` | 216 | 32 | 4096 | 12 |
| `Llama-3.1-8B-Instruct_letter_acts.pt` | 468 | 32 | 4096 | 26 |
| `Llama-3.1-8B-Instruct_month_acts.pt` | 216 | 32 | 4096 | 12 |
| `Llama-3.1-8B-Instruct_weekday_acts.pt` | 126 | 32 | 4096 | 7 |
| `Mistral-7B-Instruct-v0.3_capital2hop_acts.pt` | 144 | 32 | 4096 | 6 |
| `Mistral-7B-Instruct-v0.3_city_acts.pt` | 216 | 32 | 4096 | 12 |
| `Mistral-7B-Instruct-v0.3_color_acts.pt` | 144 | 32 | 4096 | 8 |
| `Mistral-7B-Instruct-v0.3_continent_acts.pt` | 144 | 32 | 4096 | 6 |
| `Mistral-7B-Instruct-v0.3_ctxcolor_acts.pt` | 192 | 32 | 4096 | 8 |
| `Mistral-7B-Instruct-v0.3_emotion_acts.pt` | 144 | 32 | 4096 | 8 |
| `Mistral-7B-Instruct-v0.3_letter_acts.pt` | 468 | 32 | 4096 | 26 |
| `Mistral-7B-Instruct-v0.3_month_acts.pt` | 216 | 32 | 4096 | 12 |
| `Mistral-7B-Instruct-v0.3_weekday_acts.pt` | 126 | 32 | 4096 | 7 |
| `Qwen2.5-7B-Instruct_capital2hop_acts.pt` | 144 | 28 | 3584 | 6 |
| `Qwen2.5-7B-Instruct_city_acts.pt` | 216 | 28 | 3584 | 12 |
| `Qwen2.5-7B-Instruct_color_acts.pt` | 144 | 28 | 3584 | 8 |
| `Qwen2.5-7B-Instruct_continent_acts.pt` | 144 | 28 | 3584 | 6 |
| `Qwen2.5-7B-Instruct_ctxcolor_acts.pt` | 192 | 28 | 3584 | 8 |
| `Qwen2.5-7B-Instruct_emotion_acts.pt` | 144 | 28 | 3584 | 8 |
| `Qwen2.5-7B-Instruct_hour_acts.pt` | 216 | 28 | 3584 | 12 |
| `Qwen2.5-7B-Instruct_letter_acts.pt` | 468 | 28 | 3584 | 26 |
| `Qwen2.5-7B-Instruct_month_acts.pt` | 216 | 28 | 3584 | 12 |
| `Qwen2.5-7B-Instruct_weekday_acts.pt` | 126 | 28 | 3584 | 7 |
