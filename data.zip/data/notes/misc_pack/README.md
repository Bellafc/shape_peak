# 補樣本的附帶產出（2026-10-07）

| 目錄 | 內容 |
|---|---|
| `results/dims/<模型>_<任務>.csv`、`.log` | `overnight/dims.py` 存激活時順帶算的逐層幾何：各 PC 解釋比例（ev1、ev2、ev3_4、ev5p）、去掉當層 PC1–2 後的剩餘比例（rest_frac）、各傅立葉頻率佔比（f1…）、層間 Procrustes 變化：全維 / 去掉 PC1–2 / 白化 / 頻譜（chg_full、chg_rest、chg_white、chg_fspec）。31 組，是今天補樣本新增的；白化版本恆為 0，不要用 |
| `results/fill/<模型>.log` | 補樣本佇列（`overnight/fill_queue.sh`）的完整執行日誌：存激活、`group.py` 逐層輸出、steering、lens、多位置 patching |
| `results/fill/mistral_hour.log.group / .lens` | 為跨層遷移補跑的 Mistral 小時（`group.py` FORCE、`lens.py`） |
