# 區分事件種類（形變峰對應什麼事件）資料包

建立日期：2026-10-07。`events_pack/` 下的 `results/`、`overnight/` 對應原機器的 `/workspace/results/`、`/workspace/overnight/`；要在新機器重跑，把這兩個目錄複製到 `/workspace` 下即可。

| 檔案 / 目錄 | 內容 |
|---|---|
| `FINAL_SUMMARY.md` | **最終結論**（事件分類、lens 看不到的事件、典型順序、穩健性、限制、論文板塊草稿） |
| `PROCESS.md` | 完整過程記錄：程式、時間線、遇到的問題、資料範圍、重跑方式 |
| `results/events/summary.md` | 逐步追加的工作記錄（40 組 → 敏感度與噪聲 → 48 組）；結論以 `FINAL_SUMMARY.md` 為準 |
| `results/events/signals.csv` | 49 組逐層信號（shape, id, pl, pa, pm, pc, sa, sl, lens, fisher） |
| `results/events/events.csv`、`jumps.csv` | 每個晚期層與形變峰的事件分類；各信號的跳升層 |
| `results/events/grid.png` | 6 個代表組的總圖 |
| `results/events/sensitivity.csv / .md` | 144 組門檻設定的敏感度 |
| `results/events/noise/`、`noise_summary.csv` | bootstrap 與標籤打亂（39 組） |
| `results/events/cv/`、`cv_summary.csv`、`cv_with_types.csv` | 去噪形變與同層信度、峰的去噪分類 |
| `results/<模型>/<任務>/ans/` | 各組逐層形狀 / 身份 / patching（`per_layer.csv`）與摘要（輸入） |
| `results/weekday_add/` | Qwen 星期 / 月份的逐層形狀與 patching（輸入） |
| `results/multipos/`、`steer_true/`、`lens/`、`new_metrics/` | 多位置 patching、steering、logit lens、Fisher 比（輸入） |
| `overnight/` | 全部程式（說明見 `PROCESS.md`） |

**沒有打包**：逐題激活 `results/dims/*_acts.pt`（1.9 GB），只有重跑 `shape_noise.py`、`shape_cv.py` 需要；模型權重。
