# 跨層遷移 steering（挑選建 steering 向量的層）資料包

建立日期：2026-10-07。`xfer_pack/` 下的 `results/`、`overnight/` 對應原機器的 `/workspace/results/`、`/workspace/overnight/`；要在新機器重跑，把這兩個目錄複製到 `/workspace` 下即可。

| 檔案 / 目錄 | 內容 |
|---|---|
| `summary.md` | 結論報告（前 6 節為 8 組初版；「更新：38 組」為修訂結論；文末「補充分析」為三個漏洞的檢驗與論文板塊定稿） |
| `README_sweep.md` | 強度掃描（橫線）：方法、40 組結果與修訂結論、本次單卡 B200 執行記錄（結果在 `results/steer_sweep/`） |
| `PROCESS.md` | 完整過程記錄：設計、程式、時間線、遇到的問題、重跑方式 |
| `results/steer_xfer/<模型>_<任務>.csv` | 40 組的原始 X × Y 結果（template, X, Y, n, hit, p_tgt, p_other, cos_last） |
| `results/steer_xfer/grid.png` | 總圖：4 模型 × 10 任務；形變峰按事件類型上色，綠點線 = 原生 steering 首次 ≥ 0.9 |
| `results/steer_xfer/grid_peaks.png` | 總圖：只標形變第 1 峰（實線）與第 2–3 峰（虛線） |
| `results/steer_xfer/<模型>_<任務>_heat.png` | 每組熱圖 |
| `results/steer_xfer/report.txt`、`report_rules.csv`、`report_aligned.csv`、`report_jumps.csv` | 38 組最終彙總（選法比較、峰後逐層、跳升 vs 形變峰） |
| `results/steer_xfer/extra.md`、`extra_boundary.csv`、`extra_prepeak.csv`、`extra_perm.csv` | 補充分析：邊界候選比較、峰前已有結構的層、置換檢驗 |
| `results/steer_xfer/summary.csv`、`boundary.csv`、`jump_vs_peak.csv` | 8 組初版的彙總 |
| `results/steer_xfer/dircos/`、`dircos_summary.csv` | 離線方向餘弦（39 組） |
| `results/steer_xfer/*.log` | 執行日誌（第一批按模型、第二批 `queue_g0–3.log`、Mistral 小時） |
| `results/steer_true/` | 原生 steering 結果（輸入：Y 自動限定、對照） |
| `results/events/` | 形變峰與事件分類（輸入：`events.csv`、`signals.csv`；說明 `summary.md`） |
| `overnight/` | 全部程式（說明見 `PROCESS.md` 第 2 節） |
