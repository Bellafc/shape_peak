# 強度掃描：形變峰是不是 steering 起效層的下界（橫線）

建立日期：2026-10-08。延續 `summary.md`（豎線 = 跨層遷移）。目錄對應同 `README.md`：`overnight/` → `/workspace/overnight`、`results/` → `/workspace/results`。

## 問題與做法

豎線（在第 X 層建方向）已證明形變峰是下界。橫線要問：**加在第 Y 層的 steering，最早從哪一層開始起效？是不是也不早於形變峰？**

原本的跨層圖不能直接回答，因為（1）跨層 Y 沒有往下掃到夠早；（2）強度按第 Y 層自己差值的範數縮放，峰前差值範數只有殘差的約 5%（峰後約 25%），峰前可能只是推得太小。

`overnight/steer_sweep.py`：前半段與 `steer_xfer.py` 完全相同（任務、centroid、判定；已核對 α=1、α=2 逐層與 `steer_true` 一致），後半段改成強度掃描：

- **Y**：前 25% 深度之後，到 max(第 1 峰 + 3, 原生 α=1 首次 ≥ 0.5 + 1)
- **方向**：X = Y（原生）、X = 最後一層、X = 既有 `steer_xfer` 的事後最佳 X
- **強度**：`nat` α = 1/2/4/8（× 第 Y 層自己差值的範數）；`rel` c = 0.1/0.2/0.4/0.8（× 該題該位置第 Y 層殘差範數，與各層差值範數無關）
- **對照**：同範數隨機方向（nat α=8、rel c=0.4/0.8）
- 成功 = 輸出（合併各寫法、加上「其他」類）等於目標，所以推壞不算命中；另記 p_other。

## 初版結果（本機單卡，Llama-3.1-8B 10 組）

> 2026-10-08 已補齊 Gemma / Qwen / Mistral，四模型 40 組的修訂結論見下一節「40 組結果」；本節保留為 Llama 初版記錄。

強度加大時，起效層從峰後往前移，**停在峰上或峰前 1 層**；峰前更早的層推到 α=8（約殘差的一半）或 80% 殘差範數，命中仍很低，隨機方向 ≤ 0.08。

| 任務 | 第 1 峰 | α=1 | α=2 | α=4 | α=8 | rel 0.8 |
|---|---|---|---|---|---|---|
| color | 14 | 20 | 16 | 14 | 13 | 15 |
| emotion | 13 | 16 | 14 | 13 | 13 | 14 |
| ctxcolor | 12 | 17 | 16 | 15 | 14 | 15 |
| city（可讀重組） | 14 | 17 | 16 | 14 | 14 | 14 |
| continent（可讀重組） | 14 | 17 | 16 | 14 | 14 | 14 |
| capital2hop | 16 | 17 | 16 | **14** | **14** | **14** |
| weekday | 17 | 21 | 18 | 18 | 16 | 16 |
| month | 18 | 20 | 18 | 18 | 17 | 17 |
| hour | 16 | 18 | 18 | 18 | 16 | 17 |
| letter | 18 | 18 | 18 | **16** | **14** | **15** |

彙總（`results/steer_sweep/report.txt`）：α=1 時 10/10 組起效層 ≥ 峰 − 1（中位 +3）；α=4、α=8、rel 0.8 時中位差 0，各有 2 組早於第 1 峰 > 1 層。起效時 p_other 中位 ≤ 0.02（沒有推壞）。

早於第 1 峰的 2 組：
- **capital2hop**（峰 L16）：α=4/8、rel 0.8 都停在它的**第 2 峰 L14**（可讀重組）；L13 以前 α=8 仍只有 0.30。
- **letter**（峰 L18，第 2 峰 L16 為「無事件」）：α=8 在 L14 剛過 0.5（0.53），rel 0.8 在 L15（0.51）；L13 以前 ≤ 0.24。即使以前三峰中最早的 L16 為界，也早 1–2 層。

暫定說法：**形變峰是 steering 起效層的軟下界——強度越大起效層越接近峰，極端強度（α=8，約殘差的一半；或 80% 殘差範數）下最多越過前三峰中最早的那個 1–2 層，更早的層仍推不動；常規強度（α=1）下起效層都落在峰後。**「顏色類在峰後好幾層才可 steer」主要是強度不足造成的（color α=1 +6 → α=4 0），不宜當成任務類型差異來寫。

還要確認：Gemma 顏色（α=2 已早於峰 3 層，唯一真正的反例）、第 1 峰為「集中」型的 Gemma 星期 / 月份、Qwen 顏色 / 情緒（預期停在更早的寫入峰）。

## 40 組結果（四模型，2026-10-08 補齊）

Gemma-2-9B、Qwen2.5-7B、Mistral-7B 各 10 組在單張 B200 上跑完（執行記錄見下節），連同 Llama 共 40 組。彙總：`results/steer_sweep/report.txt`（閾值 0.5）、`report_0.7.txt`、`report_onset.csv` / `report_onset_0.7.csv`。

### 起效層 − 第 1 峰（閾值 0.5，最佳方向）

| 強度 | 有起效 | 早於峰 >1 層 | 峰 ±1 | 晚於峰 >1 層 | 中位差 | 最早 | 峰前最高命中（中位 / 最大） | 起效時 p_other 中位 |
|---|---|---|---|---|---|---|---|---|
| nat α=1 | 39/40 | 2 | 19 | 18 | +1 | −3 | 0.00 / 0.64 | 0.01 |
| nat α=2 | 39/40 | 6 | 19 | 14 | 0 | −4 | 0.01 / 1.00 | 0.01 |
| nat α=4 | 39/40 | 14 | 19 | 6 | 0 | −5 | 0.12 / 1.00 | 0.01 |
| nat α=8 | 40/40 | 19 | 18 | 3 | −1 | −7 | 0.43 / 1.00 | 0.03 |
| rel 0.2 | 10/40 | 0 | 5 | 5 | +2 | 0 | 0.01 / 0.19 | 0.00 |
| rel 0.4 | 39/40 | 7 | 17 | 15 | 0 | −4 | 0.12 / 0.86 | 0.01 |
| rel 0.8 | 39/40 | 22 | 13 | 4 | −3 | −8 | 0.80 / 1.00 | 0.02 |

（rel 0.1 無一組起效。閾值 0.7 結論相同：α=1 時 0 組早於峰 >1 層、中位 +2；α=8 時 19 組、中位 −2。）

各模型中位差（起效層 − 第 1 峰）：

| 模型 | α=1 | α=2 | α=4 | α=8 | rel 0.8 |
|---|---|---|---|---|---|
| Llama | +3 | +1.5 | 0 | −0.5 | 0 |
| Gemma | 0 | 0 | −1 | −4.5 | −4 |
| Mistral | +1 | 0 | 0 | −2.5 | −3 |
| Qwen | 0 | 0 | −0.5 | −1 | −3 |

改以「前三峰中最早的一個」（`events.csv` 的第 1 峰 + 第 2–3 峰）為界：α=1 時 0/40 早於它 >1 層；α=8 時 4/40、rel 0.8 時 4/40。全部強度下早於它 >1 層的只有 5 組：**Gemma color**（峰 L29，第 2–3 峰更晚；α=2 L26、α=8 L23，最多早 6 層）、**Gemma month**（前三峰最早 L31；α=8 L26、rel 0.8 L25）、**Mistral letter**（L19；α=4/8 L17/L16）、**Mistral weekday**（L17；rel 0.8 L15）、**Llama letter**（L16；α=8 L14）。

隨機方向對照（同範數，nat α=8、rel 0.4/0.8）：所有組所有 Y 最高命中 ≤ 0.11，早於峰的起效不是「推壞」造成。

### 修訂結論

1. **常規強度（α=1，按該層自己差值的範數）下，形變峰仍是下界**：39/40 組起效層 ≥ 第 1 峰 − 1；兩個例外 Qwen color（−2）、Qwen emotion（−3）的第 1 峰都是「集中」型，且起效層不早於它們的第 2–3 峰。以前三峰最早者為界，0/40 例外。
2. **強度加大後起效層普遍越過第 1 峰**，Llama 外的三個模型比 Llama 明顯：α=8 中位 Gemma −4.5、Mistral −2.5；rel 0.8 時 22/40 組早於峰 >1 層。初版「極端強度下最多越過 1–2 層」**不成立**，最多可早 7–8 層（以第 1 峰計）。
3. 但大多數越過第 1 峰的組停在**更早的第 2–3 峰**附近：以前三峰最早者為界，α=8 仍有 36/40 組不早於它 >1 層。所以較穩的說法是：**形變峰（取前三峰中最早者）是 steering 起效層的軟下界；常規強度下幾乎無例外，極端強度（≈ 殘差範數的一半以上）下 40 組中有 4–5 組越過 2–6 層。**
4. 待確認項的結果：Gemma color 確認為真反例（α=2 已早 3 層，α=8 早 6 層，且它的第 2–3 峰都更晚）；Gemma month（集中型）也越過前三峰；Gemma weekday（集中型）以第 1 峰計早 6 層，但停在第 2–3 峰 L28 上；Qwen color / emotion 停在或晚於它們更早的第 2–3 峰。
5. 「顏色類要到峰後好幾層才可 steer」仍主要是強度不足：例如 Llama color α=1 +6 → α=4 0，Gemma ctxcolor α=1 L28 → α=8 L24。

### 需要注意的組

- **Mistral hour**：模板 2 沒有可用測試題（正確答對且答案在訓練集出現的題為空），只跑了模板 0、1；除 α=8（L19）外各強度都未過 0.5，結果最弱。原實驗 Mistral hour 也是單獨處理（`results/steer_xfer/Mistral_hour.log`）。
- **Gemma ctxcolor**：第 1 峰是 L13 的「無事件」峰，α=1 要到 L28 才起效（+15）；拿它算「峰後幾層」意義不大。
- `report.txt` 每組表格的模型名縮寫為 Gemma / Llama / Mistral / Qwen2.5。

## 本次執行記錄（單張 B200，2026-10-08）

- 機器：容器內只掛到 1 張 B200（183GB），192 邏輯核、2TB 記憶體；`/workspace` 只有 30GB，HF 快取放 `/dev/shm/hf`（`HF_HOME=/dev/shm/hf`，3 個模型約 45GB）。
- 6 個 worker 共用卡 0：`sweep_run.sh` 改為 `CUDA_VISIBLE_DEVICES=$((g % 卡數))`，worker 數可多於卡數。batch 保持 32，與 Llama 10 組設定相同。
- **執行緒超訂**：第一次（12:06）沒限制執行緒，torch 每進程預設 96 執行緒，6 進程互相搶，GPU SM 利用率只有約 12%，18 分鐘 Gemma 一層都沒跑完。12:24 停掉，改 `OMP_NUM_THREADS=8 MKL_NUM_THREADS=8` 從頭重跑（各組 csv 從頭重寫，不影響結果），GPU 利用率升到約 93%。
- 實際用時：12:24:38 開始，13:29:45 30 組全部完成，約 65 分鐘；Qwen / Mistral 每組 1–12 分鐘，Gemma 每組 9–30 分鐘。無失敗。
- `sweep_report.py` 修正：原本閾值 0.7 的彙總會覆蓋 `report_onset.csv`，現在 0.7 寫到 `report_onset_0.7.csv`。

重跑指令（單卡、多 worker）：

```bash
cd /workspace/overnight
OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 HF_HOME=/dev/shm/hf MODELS="gemma qwen mistral" \
  nohup bash sweep_run.sh 6 > /workspace/results/steer_sweep/run_nohup.log 2>&1 &
```

## 在多卡機器上跑剩下的 30 組（Gemma、Qwen、Mistral 各 10）

環境：Python 3.12、torch 2.8.0+cu128、transformers 5.18.0、scikit-learn、scipy、pandas。每卡 ≥ 24GB。硬碟約 50GB（3 個模型的 HF 快取）。模型都用不需授權的鏡像（unsloth / Qwen），與原實驗相同。

```bash
unzip xfer_sweep_pack.zip -d /tmp/x
cp -r /tmp/x/xfer_pack/overnight /tmp/x/xfer_pack/results /workspace/   # 腳本寫死 /workspace/overnight、/workspace/results
pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128
pip install transformers==5.18.0 huggingface_hub accelerate scikit-learn scipy pandas
cd /workspace/overnight
nohup bash sweep_run.sh > /workspace/results/steer_sweep/run_nohup.log 2>&1 &   # 預設用全部卡；也可 bash sweep_run.sh 4
tail -f /workspace/results/steer_sweep/run.log
```

- `sweep_run.sh` 先依序下載 3 個模型，再把還沒跑完的組（log 裡沒有 `done`）放進共享佇列，每張卡一個 worker 輪流領；中斷後重跑同一指令會跳過已完成的組。只跑部分模型：`MODELS="gemma qwen" bash sweep_run.sh`。
- 時間：A6000 上每組 8–15 分鐘（Gemma 42 層較慢）。30 組、5 張卡約 1.5 小時。
- 結束後自動彙總：`results/steer_sweep/report.txt`（閾值 0.5）、`report_0.7.txt`、`report_onset.csv`、`report_onset_0.7.csv`。
- **多個 worker 時務必設 `OMP_NUM_THREADS`**（例如 8），否則 CPU 執行緒超訂、GPU 閒置（見「本次執行記錄」）。

## 檔案

| 檔案 | 內容 |
|---|---|
| `overnight/steer_sweep.py` | 強度掃描主程式（單組）：`MK=gemma python steer_sweep.py unsloth/gemma-2-9b-it color Gemma-2-9B-it` |
| `overnight/sweep_run.sh` | 多卡佇列 + 彙總（worker 數可多於卡數，共用卡） |
| `overnight/sweep_queue.sh` | 本機單卡版（一次一個模型、跑完刪權重；依賴 `fetch_model.py`，多卡機器不需要） |
| `overnight/sweep_report.py` | 彙總：各強度起效層 − 第 1 峰、峰前最高命中、起效時 p_other、隨機對照 |
| `overnight/existing_onset.py` | 只用既有數據：原生 steering（α=1/2）、patching（pa / pl）、跨層 Y* 的起效層 vs 第 1 峰 → `existing_onset.csv` |
| `results/steer_sweep/report.txt`、`report_0.7.txt`、`report_onset.csv`、`report_onset_0.7.csv` | 40 組彙總（閾值 0.5 / 0.7） |
| `results/steer_sweep/run.log`、`<模型>_<任務>.log` | 本次執行日誌（佇列分派、每組逐 Y 進度） |
| `results/steer_sweep/<模型>_<任務>.csv` | 原始結果（template, Y, X, mode, s, n, hit, p_tgt, p_other, rel_nat） |
