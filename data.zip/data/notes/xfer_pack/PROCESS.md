# 跨層遷移 steering（挑選建 steering 向量的層）：完整過程記錄

日期：2026-10-07。機器：4 × NVIDIA RTX PRO 4000 Blackwell（24GB），Python 3.12.3、torch 2.8.0+cu128、transformers 5.18.0。
結論見 `summary.md`；本文件記錄每一步做了什麼、為什麼、遇到什麼問題。

---

## 0. 研究問題

來自 `README_explore.md` 第 2 節的方向「挑選建 steering 向量 / 概念字典的層」：
> 用第 X 層 centroid 建的方向套到第 Y 層，看形變峰值之後建的向量是否遷移得最好。

使用者的追問依序是：峰之後是所有層都能遷移，還是只有最後幾層？峰那一層是否都有一個大跳升？

## 1. 設計

- **協議沿用 `steer_true.py`**，保證與原本的 steering 結果可比：
  - centroid 只用「其他兩個模板、模型答對」的題（被 steer 的模板不參與）；
  - 只 steer 模型答對的題；目標 = 原答案往後 1…n−1 格輪流；
  - 加在問句之後的全部位置（每個位置各自一組 centroid）；
  - 成功 = 輸出（合併各寫法的第一個 token）等於目標。
- **跨層**：方向 = 第 X 層的「目標 centroid − 當前 centroid」；每個位置把它的範數縮放成第 Y 層自己那個差值的範數，再加到第 Y 層。所以只遷移方向。X = Y 時就是原本的 α=1 steering。
- **遷移力**（X）= 第 X 層建的方向，在所有「原生（X=Y）成功率 ≥ 0.9」的 Y 上的平均成功率。
- **X 範圍**：前 25% 深度之後的所有層。**Y 範圍**：第一批 4 組掃全部；之後只掃「原生 steering（全部位置 α=1，來自 `results/steer_true/`）首次 ≥ 0.3 的層 − 2」之後（更早的 Y 原生就無效，遷移不可能有效），用來加速。
- 形變峰與事件類型來自 `results/events/events.csv`（`overnight/event_types.py`，見 `results/events/summary.md`）。

## 2. 程式

| 檔案 | 作用 |
|---|---|
| `overnight/steer_xfer.py` | 跨層遷移主程式。前半段直接取自 `steer_true.py`（載入任務、模型、hook、前向、捕捉問句後各位置的殘差、判斷答對），後半段是 X × Y 掃描。`python steer_xfer.py <模型路徑> <任務> <名稱>`，環境變數 `MK` 指定家族；輸出 `results/steer_xfer/<名稱>_<任務>.csv`（template, X, Y, n, hit, p_tgt, p_other, cos_last） |
| `overnight/xfer_queue.sh` | 第一批：每張卡一個模型、跑一串任務 |
| `overnight/xfer_pairs.sh` | 第二批：每張卡一串「模型:任務」 |
| `overnight/xfer_worker.sh` | 共享佇列的取工作程式（flock 鎖住 `shared_queue.txt`，先等指定 PID 結束才開始） |
| `overnight/dir_cos.py` | 離線：用存下的答案位置激活（`results/dims/*_acts.pt`）算 centroid 差值方向的跨層餘弦 |
| `overnight/xfer_analyze.py` | 每組熱圖（`<組>_heat.png`）、各選法遷移力（`summary.csv`） |
| `overnight/xfer_report.py` | 最終彙總：選法比較、按事件類型 / 任務類別 / 模型分組、按 X − 第 1 峰對齊、跳升 vs 形變峰（`report_*.csv`、`report.txt`） |
| `overnight/xfer_extra.py` | 三個補充分析：邊界候選比較、峰前已有結構、置換檢驗（`extra.md`、`extra_*.csv`） |
| `overnight/xfer_grid.py` | 總圖：`grid.png`（形變峰按事件類型上色 + 原生 steering 線）；`PLAIN=1` 時輸出 `grid_peaks.png`（只標第 1 峰 / 第 2–3 峰） |

## 3. 執行時間線

| 時間 | 事件 |
|---|---|
| 11:20 | 寫好 `steer_xfer.py`；第一批 8 組上 4 張卡（`xfer_queue.sh`）：Llama 城市 / 月份、Qwen 城市 / 月份、Mistral 國家→洲 / 月份、Gemma 月份 / 城市。核對：X = Y 對角線與 `steer_true` 一致 |
| 11:25 | 速度約每個 Y 40 秒，預估每組 2–3 小時；在 `steer_xfer.py` 加入 Y 自動限定（之後啟動的組才生效：Llama 月份、Qwen 月份、Mistral 月份、Gemma 城市） |
| 11:30 | 離線方向餘弦（`dir_cos.py`，39 組） |
| 12:17 | 第一批 8 組完成，無失敗；初版結論與 `grid.png`（8 組） |
| 12:51 | 第二批 31 組（4 個大模型補齊其餘任務）上 4 張卡（`xfer_pairs.sh`），重任務（字母）排最後 |
| 13:30 | 3 號卡落後：停掉它的佇列迴圈（正在跑的組照常），把剩下 5 組放進共享佇列，4 張卡跑完自己的清單後去領 |
| 13:55 | 1、2 號卡清單尾端還有 4 組，同樣挪進共享佇列；領工作的程式改成等該卡**正在跑的 Python** 結束（避免一張卡同時載兩個模型） |
| 14:37 | 31 組完成，無失敗；`xfer_report.py` 彙總 38 組 |
| 15:00 | Mistral 小時（準確率 0.06，原本沒跑）：`group.py`（FORCE）補形狀、`lens.py` 補 lens、`steer_xfer.py` 補遷移；重跑 `event_types.py`（事件分類變 49 組） |
| 15:30 | `grid.png` 更新為 40 組（4 × 10）；新增 `grid_peaks.png` |
| 16:00 | 三個補充分析（`xfer_extra.py`）：邊界候選、峰前已有結構、置換檢驗；寫入 `summary.md` 並定稿論文板塊 |

## 4. 遇到的問題與處理

1. **速度**：Y 掃全部層太慢 → 加入 Y 自動限定。第一批前 4 組（Llama 城市、Qwen 城市、Mistral 國家→洲、Gemma 月份）是全 Y，其餘是限定 Y。對「可 steer 的 Y」沒有影響，但熱圖下半部覆蓋範圍不同。
2. **負載不均**：靜態分配下 3 號卡落後約 1 小時 → 兩次把未開始的組挪到共享佇列。挪動時只停佇列迴圈、不停正在跑的 Python；第二次修正了「領工作的程式只等佇列迴圈、不等 Python」可能導致一卡雙模型的風險。
3. **假的完成通知**：舊的等待條件是數 log 裡的「ALL DONE」，改成共享佇列後每領一組都會寫一次 → 改成「所有佇列 / 領工作程式都結束」。
4. **Gemma 情緒**：原生 steering 各層停在 0.84–0.90，沒有一層 ≥ 0.9，無法定義可 steer 的層 → 不計入彙總（圖上註明）。
5. **Mistral 小時**：準確率 0.06，只有第 2 個模板有 2 題可測 → 只畫在圖上（註明 only 2 test prompts），`xfer_report.py` 排除測試題 < 20 的組。
6. **8 組 → 38 組的修正**：8 組時「峰後 +4 層到 0.8」「最大跳升 7/8 在峰上」；38 組變成「+8 層」「27/38」。`summary.md` 開頭已註明前 6 節是 8 組初版，修訂結論在文末。

## 5. 最終資料範圍

- 40 組有跨層遷移數據：Qwen、Llama、Gemma 各 10 個任務，Mistral 10 個（含小時）。
- 彙總用 38 組（排除 Gemma 情緒、Mistral 小時）；準確率 < 0.55 的 4 組（Llama 字母、Gemma 小時、Mistral 字母 / 情緒）在內，去掉後數字幾乎不變。
- 離線方向餘弦：39 組（有存激活的組）。

## 6. 主要結果（摘要，詳見 `summary.md` 文末「更新：38 組」）

- 峰前 5 層建的方向：遷移力 0.07（中位 0.01）；峰及之後：0.74。
- 峰那一層：0.37；峰後逐層上升，平均 +8 層到 0.8、+10～12 層最高（約 0.90）；Qwen 約 2 層、Gemma 5、Llama 7、Mistral 8。
- 最大跳升落在第 1–3 峰：27/38（隨機約 0.13）；在寫入 21、集中 6、非峰 11、可讀重組 0；只有 12/38 在第 1 峰本身大跳。
- 選法比較：最後一層 0.92、原生 steering ≥ 0.9 的層 0.76、80% 深度 0.72、lens ≥ 0.1 的層 0.67、第 1 峰 0.37。

## 6b. 補充分析（見 `summary.md` 文末）

- 邊界候選：形變峰之前 5 層遷移力 0.07（最乾淨），但誤差 3.2 層；lens 誤差 1.6 層但之前已有 0.24；身份探針與同層信度早 5–7 層。
- 峰前、同層信度 ≥ 0.9 的層：遷移力 0.14（峰後同信度 0.80）。
- 置換檢驗：最大跳升在第 1–3 峰上 27/38（虛無 4.8），p < 0.0001。

## 7. 重跑方式

```bash
cd /workspace/overnight
# 單組（MK = qwen / llama / gemma / mistral；模型路徑可用 HF repo 名）
MK=llama python steer_xfer.py unsloth/Llama-3.1-8B-Instruct city Llama-3.1-8B-Instruct
# 彙總與圖
python xfer_analyze.py      # 每組熱圖、summary.csv
python xfer_report.py       # report_*.csv、印出彙總表
python xfer_grid.py         # grid.png
PLAIN=1 python xfer_grid.py # grid_peaks.png
python dir_cos.py           # 離線方向餘弦（需要 results/dims/*_acts.pt）
python xfer_extra.py        # 三個補充分析（需要 results/events/cv/、Qwen 星期 / 月份需 results/dims/*_acts.pt）
```
需要 `results/events/events.csv`（形變峰與事件類型）與 `results/steer_true/<名稱>_<任務>.csv`（Y 自動限定）。`steer_xfer.py` 依賴 `group.py` 與 `new_concepts.py`（任務定義、模型載入）。
