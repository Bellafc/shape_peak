# 交接 steering 測試（輸入 token → 答案位置）

在新機器（A40 48GB）上於 2026-10-07 完成。解壓到 `/workspace` 即可，路徑與原專案相同。

## 要回答的問題

形變層（起始層）之前，改變答案的有效槓桿在輸入 token 上；之後轉移到答案位置。原本只有 patching 證據，這次用 **steering** 驗證，並逐組量交接區的寬度。

## 一句話結論

輸入 token 的作用在形變層附近 1–2 層內消失（8 組中 6 組正好在形狀峰值 ±1 層；Gemma 提早 4–5 層，在它的「第一次寫入」層 L29）。交接區**不是兩邊同時有效的重疊**，而是多步寫入模型（Llama、Mistral、Gemma）有 3–4 層「兩邊都推不太動」的空檔；一步寫完的 Qwen 是乾淨的一層切換。多步模型的「只改最後位置」比「問句後全部位置」晚 2–7 層生效（三段式：輸入 → 中繼 → 最後位置）。

完整結果與表格：`results/handoff/SUMMARY.md`；圖：`results/handoff/handoff.png`。

## 檔案

| 路徑 | 內容 |
|---|---|
| `overnight/steer_handoff.py` | 主程式：逐層做輸入 token steering 與答案位置 steering（自然強度、相對範數 0.5 / 1.0、隨機對照；問句後全部位置 / 只改最後位置） |
| `overnight/handoff_plot.py` | 從逐層 csv 算失效層、生效層、交叉層、空檔，畫 `handoff.png`、寫 `summary.csv` |
| `overnight/run_handoff.sh`、`overnight/handoff_cases.tsv` | 依案例清單逐一跑（換模型前清 HF 快取） |
| `overnight/group.py`、`overnight/new_concepts.py` | 共用前置程式（任務定義、題目、答案 token），主程式用它載入 |
| `results/handoff/<模型>_<任務>.csv` | 逐層 × 條件：hit（輸出 = 目標）、keep（維持原答案）、other、實際相對範數 |
| `results/handoff/<模型>_<任務>.log` | 執行紀錄 |
| `results/handoff/summary.csv`、`handoff.png`、`SUMMARY.md` | 摘要、圖、總結 |

## 重跑

```
cd /workspace/overnight
MK=qwen python steer_handoff.py Qwen/Qwen2.5-7B-Instruct weekday Qwen2.5-7B-Instruct    # 單組
CASES=handoff_cases.tsv sh run_handoff.sh                                               # 清單（第一組 Gemma 星期需另外跑）
python handoff_plot.py
```

環境：torch 2.8.0+cu128、transformers 5.18.0、huggingface_hub 1.33.0（與原 README 第 2 節相同）。每組 5–17 分鐘（Gemma 月份最久）。

## 設計要點

- 只用模型答對的題；每題換新起點 s'，目標 (s' + k) mod n，兩種 steering 朝同一個目標。
- 輸入方向：起點詞最後一個 token 上「新起點 centroid − 原起點 centroid」；答案方向：問句後每個位置上「目標答案 centroid − 原答案 centroid」。centroid 只用另外兩個問法裡答對的題。
- 失效 / 生效用固定門檻 0.5。形狀峰值與 steering 起始層取自 `results/depth_vs_shape.csv`（原機器）。

## 還沒做

檢索類任務（城市、國家 → 洲）：沒有「起點 + k」結構，輸入方向需另外定義（例如在線索 token 上按答案類別的 centroid）。
