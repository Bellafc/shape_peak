# Qwen2.5-1.5B-Instruct 星期 答案位置

跳過：skipped：準確率過低（煙霧測試 0.25，第一個 token 0.56）
