# Activations (not in this repository)

The answer-position activations (`*_acts.pt`, written by `experiments/02_setup/dims.py`) are 1.7 GB for the two v2 models
and are not included in the GitHub version. They are in the full release (`release_v2_full.zip`); the original four models'
activations are in the first release.

They are needed only for the overview figures of the v2 models (`sec1_overview/fig1.py`) and for re-running the theory and
noise checks (`experiments/07_theory/`); without them `reproduce.sh` skips those steps and everything else runs.
The outputs of those checks are included (`data/theory/`). To regenerate the activations, run `dims.py` for the model
(see `experiments/README.md`).
