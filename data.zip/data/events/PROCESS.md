# 區分事件種類：完整過程記錄

日期：2026-10-07。機器：4 × NVIDIA RTX PRO 4000 Blackwell（24GB），Python 3.12.3、torch 2.8.0+cu128、transformers 5.18.0。結論見 `FINAL_SUMMARY.md`。

## 0. 研究問題

來自 `README_explore.md` 第 2 節「建議探索的方向（logit lens 做不到、形變峰值可能做得到）」的第二條：
> 區分事件種類：lens 只有一條「越來越像輸出」的曲線；形變峰值能把「可讀並重組」（Llama 城市 L14）和「寫入」（L16–17）分開。對每組（模型 × 任務）列出所有形變小峰，對照 patching / steering / lens 的跳升，建立事件分類。

使用者之後要求：(1) 門檻敏感度與噪聲基線；(2) 用 4 張卡補樣本。

## 1. 程式

| 檔案 | 作用 |
|---|---|
| `overnight/event_types.py` | 收集每組逐層信號（`signals.csv`）、找形變峰、對每個晚期層分類（`events.csv`）、各信號跳升（`jumps.csv`），印出峰 vs 非峰的類型分布 |
| `overnight/event_plot.py` | 6 個代表組的總圖（`grid.png`） |
| `overnight/event_sensitivity.py` | 144 組門檻設定的敏感度（`sensitivity.csv`、`sensitivity.md`） |
| `overnight/shape_noise.py` | 用存下的激活做 bootstrap（峰位置穩定度）與標籤打亂（`noise/`、`noise_summary.csv`） |
| `overnight/shape_cv.py` | 去噪（交叉驗證）的形變與同層信度，將第 1–3 峰分為重組 / 結構出現 / 不顯著 / 結構不可靠（`cv/`、`cv_summary.csv`） |
| `overnight/fill_queue.sh` | 補樣本佇列：存激活（`dims.py`）→ 逐層形狀（`group.py`）→ steering（`steer_true.py`）→ lens（`lens.py`）→ 多位置 patching（`multipos.py`） |
| 依賴 | `group.py`、`new_concepts.py`、`dims.py`、`lens.py`、`steer_true.py`、`multipos.py` |

信號來源（全部在答案位置）：`results/<模型>/<任務>/ans/per_layer.csv`（形變 `change_full`、身份探針、最後位置整個殘差 patching）；Qwen 星期 / 月份用 `results/weekday_add/` 的 `shape.csv`、`causal.csv`、`months/ans.csv`；`results/multipos/`（全部位置 / 最後 + 中繼 / centroid 子空間 patching）；`results/steer_true/`（steering）；`results/lens/`；`results/new_metrics/` 與 `results/dims/*_acts.pt`（Fisher 比，部分組）。

## 2. 時間線

| 時間 | 事件 |
|---|---|
| 07:35 | 盤點既有結果；確認各腳本層號一致（L = 第 L 個 decoder 層的輸出） |
| 07:50 | `event_types.py` 第一版：40 組；第一次門檻（1.5 倍中位數）峰太多 → 改為對每個晚期層套同一規則，比較峰 vs 非峰；`event_plot.py` 總圖 |
| 07:55 | 檢驗「不干預能否分開可讀重組與寫入」：11 vs 11，不能 |
| 08:10 | 刪除不需要的 Qwen-VL 快取（騰出磁碟）；4 個模型下載到 `/dev/shm`（Qwen 放硬碟） |
| 08:12 | 4 張卡啟動補樣本佇列（`fill_queue.sh`）；同時跑門檻敏感度（`event_sensitivity.py`，144 組設定） |
| 08:14–08:36 | 噪聲基線（`shape_noise.py`，39 組，B = 100）：bootstrap 與標籤打亂 |
| 08:38–08:42 | 去噪形變（`shape_cv.py`）：第一版估計量爆掉（分母趨近 0、核範數被噪聲推高）→ 改為四份樣本的無偏距離矩陣 + 衰減校正；顯著性改用「≥ 80% 的分法 > 2 倍基準」 |
| 09:59 | 補樣本完成（無失敗）：新增 Mistral 星期 / 月份 / 顏色 / 情緒 / 字母、Gemma 小時 / 字母、Llama 字母；補 steering、lens、多位置 patching |
| 11:00 | 48 組重跑分類、敏感度、去噪合併 |
| 15:25 | 為跨層遷移圖補跑 Mistral 小時（`group.py` FORCE、`lens.py`）；事件分類變 49 組 |
| 16:10 | 49 組重跑分類與敏感度；寫 `FINAL_SUMMARY.md` |

## 3. 遇到的問題與處理

1. **峰太多**：1.5 倍中位數的門檻讓一組冒出很多小峰，而 ±1 層窗口內本來就常有跳升 → 改為「每一個晚期層都分類」，用非峰層當基準；峰按高度分第 1、第 2–3、其他。
2. **早期層**：前 25% 深度的形變（嵌入 / 模板處理）另列，不參與分類；噪聲基線後證實答案出現前按答案分組的排列本來就不可靠（同層信度低）。
3. **磁碟不足**：30GB 硬碟裝不下 4 個模型 → 3 個放 `/dev/shm`；刪 Qwen-VL 時先確認 blob 的 `.refs` 屬於哪個倉庫，只刪 VL 的。
4. **標籤打亂的虛無分布有偏**：Procrustes 先歸一化，純噪聲排列的層間變化天生較大，且寫入層「從無到有」無法在打亂下出現 → 不拿它做顯著性檢定，改用去噪形變。
5. **去噪估計量**：第一版（核範數 / 內積）在答案未寫入的層分母趨近 0 而爆掉 → 改為四份樣本的無偏類間距離矩陣餘弦，再除以同層信度。
6. **背景程式自殺**：`pkill -f shape_cv.py` 匹配到自己所在的 shell → 改用 PID。
7. **每類題數太少**：部分計算類任務四份樣本每類只有 4–5 題，同層信度估計偏低 → 標為「無法判斷」，不下結論。

## 4. 資料範圍

- 事件分類：49 組（4 個大模型各 10 個任務 + 小模型 9 組）。
- 敏感度：49 組 × 144 組設定。
- 噪聲 / 去噪：39 組（有存激活的組；小模型與 Mistral 小時沒有）。
- 準確率 < 0.55 的 6 組另列，去掉後結論不變。

## 5. 重跑方式

```bash
cd /workspace/overnight
python event_types.py          # signals.csv、events.csv、jumps.csv
python event_plot.py           # grid.png
python event_sensitivity.py    # sensitivity.csv / .md
python shape_noise.py          # noise/、noise_summary.csv（需要 results/dims/*_acts.pt）
python shape_cv.py             # cv/、cv_summary.csv（同上）
# 補樣本（每張卡一個模型）：
CUDA_VISIBLE_DEVICES=0 bash fill_queue.sh <MK> <repo> <名稱> <HF_HOME> "<dims 任務>" "<group 任務>" "<FORCE group 任務>" "<steer 任務>" "<lens 任務,逗號分隔>" "<multipos 任務>"
```
